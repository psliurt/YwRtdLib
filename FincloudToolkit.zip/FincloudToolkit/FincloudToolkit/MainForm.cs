﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FincloudToolkit
{
    public partial class MainForm : Form
    {
        private const string DirSettingFileName = "./setting.txt";
        public MainForm()
        {
            InitializeComponent();
        }

        private void _openDirectoryBtn_Click(object sender, EventArgs e)
        {
            if (this._directoryDlg.ShowDialog() != System.Windows.Forms.DialogResult.OK)
            {
                return;    
            }
            this._outputDirectoryTxt.Text = this._directoryDlg.SelectedPath;
        }

        private void _saveDirectorySettingBtn_Click(object sender, EventArgs e)
        {
            using (StreamWriter sw = new StreamWriter(MainForm.DirSettingFileName, false))
            {
                sw.WriteLine(this._outputDirectoryTxt.Text.Trim());
                sw.WriteLine(this._outputFileNameTxt.Text.Trim());
            }
            MessageBox.Show("儲存成功");
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            using (StreamReader sr = new StreamReader(MainForm.DirSettingFileName))
            {
                this._outputDirectoryTxt.Text = sr.ReadLine();
                this._outputFileNameTxt.Text = sr.ReadLine();
            }
        }

        private void _generateBtn_Click(object sender, EventArgs e)
        {
            string outputPath = Path.Combine(this._outputDirectoryTxt.Text, string.Format("{0}.csv", this._outputFileNameTxt.Text));
            string buyOrSell = this._buyRdoBtn.Checked ? "B" : "S";
            using (StreamWriter sw = new StreamWriter(outputPath, false))
            {
                sw.WriteLine("{0},{1},{2},{3}", this._symbolTxt.Text.Trim().ToUpper(), buyOrSell, this._priceTxt.Text.Trim(), this._qtyTxt.Text.Trim());
            }
        }
    }
}
