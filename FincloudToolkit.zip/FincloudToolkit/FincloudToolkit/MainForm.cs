﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FincloudToolkit
{
    public partial class MainForm : Form
    {
        private const string DirSettingFileName = "./setting.txt";
        public MainForm()
        {
            InitializeComponent();
        }

        private void _openDirectoryBtn_Click(object sender, EventArgs e)
        {
            if (this._directoryDlg.ShowDialog() != System.Windows.Forms.DialogResult.OK)
            {
                return;    
            }
            this._outputDirectoryTxt.Text = this._directoryDlg.SelectedPath;
        }

        private void _saveDirectorySettingBtn_Click(object sender, EventArgs e)
        {
            using (StreamWriter sw = new StreamWriter(MainForm.DirSettingFileName, false))
            {
                sw.WriteLine(this._outputDirectoryTxt.Text.Trim());
                sw.WriteLine(this._outputFileNameTxt.Text.Trim());
            }
            MessageBox.Show("儲存成功");
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            using (StreamReader sr = new StreamReader(MainForm.DirSettingFileName))
            {
                this._outputDirectoryTxt.Text = sr.ReadLine();
                this._outputFileNameTxt.Text = sr.ReadLine();
            }
        }

        private void _generateBtn_Click(object sender, EventArgs e)
        {
            string outputPath = Path.Combine(this._outputDirectoryTxt.Text, string.Format("{0}.csv", this._outputFileNameTxt.Text));
            string buyOrSell = this._buyRdoBtn.Checked ? "B" : "S";
            StringBuilder batchStr = GenerateBatchString(buyOrSell);
            if (batchStr.Length > 0)
            {
                using (StreamWriter sw = new StreamWriter(outputPath, false))
                {
                    sw.Write(batchStr.ToString());
                }
            }
            MessageBox.Show("產生完畢");
        }

        private StringBuilder GenerateBatchString(string buyOrSell)
        {
            int qty = Convert.ToInt32(this._qtyTxt.Text);
            if (qty == 0) { return new StringBuilder(); }

            StringBuilder sb = new StringBuilder();           

            while (qty > 0)
            {
                if (qty < 100)
                {
                    sb.AppendFormat("{0},{1},{2},{3}", this._symbolTxt.Text.Trim().ToUpper(), buyOrSell, this._priceTxt.Text.Trim(), qty).AppendLine();
                    qty = 0;
                }
                else
                {
                    sb.AppendFormat("{0},{1},{2},{3}", this._symbolTxt.Text.Trim().ToUpper(), buyOrSell, this._priceTxt.Text.Trim(), 100).AppendLine();
                    qty -= 100;
                }
            }
            return sb;
        }

        private void _taifex11RdoBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (this._taifex11RdoBtn.Checked)
            {
                this._symbolTxt.Text = "TXFK7.tw";
            }
        }

        private void _taifex12RdoBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (this._taifex12RdoBtn.Checked)
            {
                this._symbolTxt.Text = "TXFL7.tw";
            }
        }        

        private void _CallRdo_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rdoBtn = sender as RadioButton;
            if (rdoBtn.Checked)
            {
                string target = rdoBtn.Name.Substring(8, 5);
                if (rdoBtn.Name.StartsWith("_nov"))
                {
                    this._symbolTxt.Text = string.Format("TXO{0}K7.TW", target);
                }
                if (rdoBtn.Name.StartsWith("_dec"))
                {
                    this._symbolTxt.Text = string.Format("TXO{0}L7.TW", target);
                }
                if (rdoBtn.Name.StartsWith("_jan"))
                {
                    this._symbolTxt.Text = string.Format("TXO{0}A8.TW", target);
                }
            }            
        }

        private void _PutRdo_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rdoBtn = sender as RadioButton;
            if (rdoBtn.Checked)
            {
                string target = rdoBtn.Name.Substring(7, 5);
                if (rdoBtn.Name.StartsWith("_nov"))
                {
                    this._symbolTxt.Text = string.Format("TXO{0}W7.TW", target);
                }
                if (rdoBtn.Name.StartsWith("_dec"))
                {
                    this._symbolTxt.Text = string.Format("TXO{0}X7.TW", target);
                }
                if (rdoBtn.Name.StartsWith("_jan"))
                {
                    this._symbolTxt.Text = string.Format("TXO{0}M8.TW", target);
                }
            }  
        }
    }
}
