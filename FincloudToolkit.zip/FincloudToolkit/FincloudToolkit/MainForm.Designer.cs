﻿namespace FincloudToolkit
{
    partial class MainForm
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this._generateBtn = new System.Windows.Forms.Button();
            this._directoryLbl = new System.Windows.Forms.Label();
            this._batchFileNameLbl = new System.Windows.Forms.Label();
            this._outputDirectoryTxt = new System.Windows.Forms.TextBox();
            this._outputFileNameTxt = new System.Windows.Forms.TextBox();
            this._saveDirectorySettingBtn = new System.Windows.Forms.Button();
            this._openDirectoryBtn = new System.Windows.Forms.Button();
            this._directoryDlg = new System.Windows.Forms.FolderBrowserDialog();
            this._symbolTxt = new System.Windows.Forms.TextBox();
            this._buyRdoBtn = new System.Windows.Forms.RadioButton();
            this._sellRdoBtn = new System.Windows.Forms.RadioButton();
            this._priceTxt = new System.Windows.Forms.TextBox();
            this._qtyTxt = new System.Windows.Forms.TextBox();
            this._symbolLbl = new System.Windows.Forms.Label();
            this._priceLbl = new System.Windows.Forms.Label();
            this._qtyLbl = new System.Windows.Forms.Label();
            this._freqSymbolGbx = new System.Windows.Forms.GroupBox();
            this._janPut11000Rdo = new System.Windows.Forms.RadioButton();
            this._janPut10900Rdo = new System.Windows.Forms.RadioButton();
            this._janPut10800Rdo = new System.Windows.Forms.RadioButton();
            this._janPut10700Rdo = new System.Windows.Forms.RadioButton();
            this._janPut10600Rdo = new System.Windows.Forms.RadioButton();
            this._janPut10500Rdo = new System.Windows.Forms.RadioButton();
            this._janCall11000Rdo = new System.Windows.Forms.RadioButton();
            this._janCall10900Rdo = new System.Windows.Forms.RadioButton();
            this._janCall10800Rdo = new System.Windows.Forms.RadioButton();
            this._janCall10700Rdo = new System.Windows.Forms.RadioButton();
            this._janCall10600Rdo = new System.Windows.Forms.RadioButton();
            this._janCall10500Rdo = new System.Windows.Forms.RadioButton();
            this._decPut11000Rdo = new System.Windows.Forms.RadioButton();
            this._decPut10900Rdo = new System.Windows.Forms.RadioButton();
            this._decPut10800Rdo = new System.Windows.Forms.RadioButton();
            this._decPut10700Rdo = new System.Windows.Forms.RadioButton();
            this._decPut10600Rdo = new System.Windows.Forms.RadioButton();
            this._decPut10500Rdo = new System.Windows.Forms.RadioButton();
            this._decCall11000Rdo = new System.Windows.Forms.RadioButton();
            this._decCall10900Rdo = new System.Windows.Forms.RadioButton();
            this._decCall10800Rdo = new System.Windows.Forms.RadioButton();
            this._decCall10700Rdo = new System.Windows.Forms.RadioButton();
            this._decCall10600Rdo = new System.Windows.Forms.RadioButton();
            this._decCall10500Rdo = new System.Windows.Forms.RadioButton();
            this._novPut11000Rdo = new System.Windows.Forms.RadioButton();
            this._novPut10900Rdo = new System.Windows.Forms.RadioButton();
            this._novPut10800Rdo = new System.Windows.Forms.RadioButton();
            this._novPut10700Rdo = new System.Windows.Forms.RadioButton();
            this._novPut10600Rdo = new System.Windows.Forms.RadioButton();
            this._novPut10500Rdo = new System.Windows.Forms.RadioButton();
            this._novCall11000Rdo = new System.Windows.Forms.RadioButton();
            this._novCall10900Rdo = new System.Windows.Forms.RadioButton();
            this._novCall10800Rdo = new System.Windows.Forms.RadioButton();
            this._novCall10700Rdo = new System.Windows.Forms.RadioButton();
            this._novCall10600Rdo = new System.Windows.Forms.RadioButton();
            this._novCall10500Rdo = new System.Windows.Forms.RadioButton();
            this._taifex12RdoBtn = new System.Windows.Forms.RadioButton();
            this._taifex11RdoBtn = new System.Windows.Forms.RadioButton();
            this._freqSymbolGbx.SuspendLayout();
            this.SuspendLayout();
            // 
            // _generateBtn
            // 
            this._generateBtn.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._generateBtn.Location = new System.Drawing.Point(489, 108);
            this._generateBtn.Name = "_generateBtn";
            this._generateBtn.Size = new System.Drawing.Size(206, 34);
            this._generateBtn.TabIndex = 0;
            this._generateBtn.Text = "產生批次檔";
            this._generateBtn.UseVisualStyleBackColor = true;
            this._generateBtn.Click += new System.EventHandler(this._generateBtn_Click);
            // 
            // _directoryLbl
            // 
            this._directoryLbl.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._directoryLbl.Location = new System.Drawing.Point(12, 13);
            this._directoryLbl.Name = "_directoryLbl";
            this._directoryLbl.Size = new System.Drawing.Size(100, 23);
            this._directoryLbl.TabIndex = 1;
            this._directoryLbl.Text = "資料夾";
            this._directoryLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // _batchFileNameLbl
            // 
            this._batchFileNameLbl.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._batchFileNameLbl.Location = new System.Drawing.Point(12, 53);
            this._batchFileNameLbl.Name = "_batchFileNameLbl";
            this._batchFileNameLbl.Size = new System.Drawing.Size(100, 23);
            this._batchFileNameLbl.TabIndex = 2;
            this._batchFileNameLbl.Text = "檔案名稱";
            this._batchFileNameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // _outputDirectoryTxt
            // 
            this._outputDirectoryTxt.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._outputDirectoryTxt.Location = new System.Drawing.Point(118, 9);
            this._outputDirectoryTxt.Name = "_outputDirectoryTxt";
            this._outputDirectoryTxt.Size = new System.Drawing.Size(465, 27);
            this._outputDirectoryTxt.TabIndex = 3;
            // 
            // _outputFileNameTxt
            // 
            this._outputFileNameTxt.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._outputFileNameTxt.Location = new System.Drawing.Point(118, 53);
            this._outputFileNameTxt.Name = "_outputFileNameTxt";
            this._outputFileNameTxt.Size = new System.Drawing.Size(423, 27);
            this._outputFileNameTxt.TabIndex = 4;
            // 
            // _saveDirectorySettingBtn
            // 
            this._saveDirectorySettingBtn.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._saveDirectorySettingBtn.Location = new System.Drawing.Point(547, 47);
            this._saveDirectorySettingBtn.Name = "_saveDirectorySettingBtn";
            this._saveDirectorySettingBtn.Size = new System.Drawing.Size(148, 34);
            this._saveDirectorySettingBtn.TabIndex = 5;
            this._saveDirectorySettingBtn.Text = "保存資料夾設定";
            this._saveDirectorySettingBtn.UseVisualStyleBackColor = true;
            this._saveDirectorySettingBtn.Click += new System.EventHandler(this._saveDirectorySettingBtn_Click);
            // 
            // _openDirectoryBtn
            // 
            this._openDirectoryBtn.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._openDirectoryBtn.Location = new System.Drawing.Point(589, 7);
            this._openDirectoryBtn.Name = "_openDirectoryBtn";
            this._openDirectoryBtn.Size = new System.Drawing.Size(106, 34);
            this._openDirectoryBtn.TabIndex = 6;
            this._openDirectoryBtn.Text = "選取資料夾";
            this._openDirectoryBtn.UseVisualStyleBackColor = true;
            this._openDirectoryBtn.Click += new System.EventHandler(this._openDirectoryBtn_Click);
            // 
            // _symbolTxt
            // 
            this._symbolTxt.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._symbolTxt.Location = new System.Drawing.Point(12, 114);
            this._symbolTxt.Name = "_symbolTxt";
            this._symbolTxt.Size = new System.Drawing.Size(137, 27);
            this._symbolTxt.TabIndex = 7;
            // 
            // _buyRdoBtn
            // 
            this._buyRdoBtn.Location = new System.Drawing.Point(155, 112);
            this._buyRdoBtn.Name = "_buyRdoBtn";
            this._buyRdoBtn.Size = new System.Drawing.Size(55, 27);
            this._buyRdoBtn.TabIndex = 8;
            this._buyRdoBtn.TabStop = true;
            this._buyRdoBtn.Text = "Buy";
            this._buyRdoBtn.UseVisualStyleBackColor = true;
            // 
            // _sellRdoBtn
            // 
            this._sellRdoBtn.Location = new System.Drawing.Point(216, 112);
            this._sellRdoBtn.Name = "_sellRdoBtn";
            this._sellRdoBtn.Size = new System.Drawing.Size(55, 27);
            this._sellRdoBtn.TabIndex = 9;
            this._sellRdoBtn.TabStop = true;
            this._sellRdoBtn.Text = "Sell";
            this._sellRdoBtn.UseVisualStyleBackColor = true;
            // 
            // _priceTxt
            // 
            this._priceTxt.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._priceTxt.Location = new System.Drawing.Point(277, 113);
            this._priceTxt.Name = "_priceTxt";
            this._priceTxt.Size = new System.Drawing.Size(100, 27);
            this._priceTxt.TabIndex = 10;
            // 
            // _qtyTxt
            // 
            this._qtyTxt.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._qtyTxt.Location = new System.Drawing.Point(383, 112);
            this._qtyTxt.Name = "_qtyTxt";
            this._qtyTxt.Size = new System.Drawing.Size(97, 27);
            this._qtyTxt.TabIndex = 11;
            // 
            // _symbolLbl
            // 
            this._symbolLbl.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._symbolLbl.Location = new System.Drawing.Point(12, 88);
            this._symbolLbl.Name = "_symbolLbl";
            this._symbolLbl.Size = new System.Drawing.Size(162, 23);
            this._symbolLbl.TabIndex = 12;
            this._symbolLbl.Text = "商品";
            this._symbolLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _priceLbl
            // 
            this._priceLbl.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._priceLbl.Location = new System.Drawing.Point(277, 88);
            this._priceLbl.Name = "_priceLbl";
            this._priceLbl.Size = new System.Drawing.Size(100, 23);
            this._priceLbl.TabIndex = 13;
            this._priceLbl.Text = "價格";
            this._priceLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _qtyLbl
            // 
            this._qtyLbl.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._qtyLbl.Location = new System.Drawing.Point(383, 88);
            this._qtyLbl.Name = "_qtyLbl";
            this._qtyLbl.Size = new System.Drawing.Size(100, 23);
            this._qtyLbl.TabIndex = 14;
            this._qtyLbl.Text = "數量";
            this._qtyLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _freqSymbolGbx
            // 
            this._freqSymbolGbx.Controls.Add(this._janPut11000Rdo);
            this._freqSymbolGbx.Controls.Add(this._janPut10900Rdo);
            this._freqSymbolGbx.Controls.Add(this._janPut10800Rdo);
            this._freqSymbolGbx.Controls.Add(this._janPut10700Rdo);
            this._freqSymbolGbx.Controls.Add(this._janPut10600Rdo);
            this._freqSymbolGbx.Controls.Add(this._janPut10500Rdo);
            this._freqSymbolGbx.Controls.Add(this._janCall11000Rdo);
            this._freqSymbolGbx.Controls.Add(this._janCall10900Rdo);
            this._freqSymbolGbx.Controls.Add(this._janCall10800Rdo);
            this._freqSymbolGbx.Controls.Add(this._janCall10700Rdo);
            this._freqSymbolGbx.Controls.Add(this._janCall10600Rdo);
            this._freqSymbolGbx.Controls.Add(this._janCall10500Rdo);
            this._freqSymbolGbx.Controls.Add(this._decPut11000Rdo);
            this._freqSymbolGbx.Controls.Add(this._decPut10900Rdo);
            this._freqSymbolGbx.Controls.Add(this._decPut10800Rdo);
            this._freqSymbolGbx.Controls.Add(this._decPut10700Rdo);
            this._freqSymbolGbx.Controls.Add(this._decPut10600Rdo);
            this._freqSymbolGbx.Controls.Add(this._decPut10500Rdo);
            this._freqSymbolGbx.Controls.Add(this._decCall11000Rdo);
            this._freqSymbolGbx.Controls.Add(this._decCall10900Rdo);
            this._freqSymbolGbx.Controls.Add(this._decCall10800Rdo);
            this._freqSymbolGbx.Controls.Add(this._decCall10700Rdo);
            this._freqSymbolGbx.Controls.Add(this._decCall10600Rdo);
            this._freqSymbolGbx.Controls.Add(this._decCall10500Rdo);
            this._freqSymbolGbx.Controls.Add(this._novPut11000Rdo);
            this._freqSymbolGbx.Controls.Add(this._novPut10900Rdo);
            this._freqSymbolGbx.Controls.Add(this._novPut10800Rdo);
            this._freqSymbolGbx.Controls.Add(this._novPut10700Rdo);
            this._freqSymbolGbx.Controls.Add(this._novPut10600Rdo);
            this._freqSymbolGbx.Controls.Add(this._novPut10500Rdo);
            this._freqSymbolGbx.Controls.Add(this._novCall11000Rdo);
            this._freqSymbolGbx.Controls.Add(this._novCall10900Rdo);
            this._freqSymbolGbx.Controls.Add(this._novCall10800Rdo);
            this._freqSymbolGbx.Controls.Add(this._novCall10700Rdo);
            this._freqSymbolGbx.Controls.Add(this._novCall10600Rdo);
            this._freqSymbolGbx.Controls.Add(this._novCall10500Rdo);
            this._freqSymbolGbx.Controls.Add(this._taifex12RdoBtn);
            this._freqSymbolGbx.Controls.Add(this._taifex11RdoBtn);
            this._freqSymbolGbx.Location = new System.Drawing.Point(10, 147);
            this._freqSymbolGbx.Name = "_freqSymbolGbx";
            this._freqSymbolGbx.Size = new System.Drawing.Size(685, 245);
            this._freqSymbolGbx.TabIndex = 15;
            this._freqSymbolGbx.TabStop = false;
            this._freqSymbolGbx.Text = "常用商品區";
            // 
            // _janPut11000Rdo
            // 
            this._janPut11000Rdo.ForeColor = System.Drawing.Color.Green;
            this._janPut11000Rdo.Location = new System.Drawing.Point(537, 207);
            this._janPut11000Rdo.Name = "_janPut11000Rdo";
            this._janPut11000Rdo.Size = new System.Drawing.Size(100, 25);
            this._janPut11000Rdo.TabIndex = 37;
            this._janPut11000Rdo.TabStop = true;
            this._janPut11000Rdo.Text = "1月Put 11000";
            this._janPut11000Rdo.UseVisualStyleBackColor = true;
            this._janPut11000Rdo.CheckedChanged += new System.EventHandler(this._PutRdo_CheckedChanged);
            // 
            // _janPut10900Rdo
            // 
            this._janPut10900Rdo.ForeColor = System.Drawing.Color.Green;
            this._janPut10900Rdo.Location = new System.Drawing.Point(431, 207);
            this._janPut10900Rdo.Name = "_janPut10900Rdo";
            this._janPut10900Rdo.Size = new System.Drawing.Size(100, 25);
            this._janPut10900Rdo.TabIndex = 36;
            this._janPut10900Rdo.TabStop = true;
            this._janPut10900Rdo.Text = "1月Put 10900";
            this._janPut10900Rdo.UseVisualStyleBackColor = true;
            this._janPut10900Rdo.CheckedChanged += new System.EventHandler(this._PutRdo_CheckedChanged);
            // 
            // _janPut10800Rdo
            // 
            this._janPut10800Rdo.ForeColor = System.Drawing.Color.Green;
            this._janPut10800Rdo.Location = new System.Drawing.Point(325, 207);
            this._janPut10800Rdo.Name = "_janPut10800Rdo";
            this._janPut10800Rdo.Size = new System.Drawing.Size(100, 25);
            this._janPut10800Rdo.TabIndex = 35;
            this._janPut10800Rdo.TabStop = true;
            this._janPut10800Rdo.Text = "1月Put 10800";
            this._janPut10800Rdo.UseVisualStyleBackColor = true;
            this._janPut10800Rdo.CheckedChanged += new System.EventHandler(this._PutRdo_CheckedChanged);
            // 
            // _janPut10700Rdo
            // 
            this._janPut10700Rdo.ForeColor = System.Drawing.Color.Green;
            this._janPut10700Rdo.Location = new System.Drawing.Point(219, 207);
            this._janPut10700Rdo.Name = "_janPut10700Rdo";
            this._janPut10700Rdo.Size = new System.Drawing.Size(100, 25);
            this._janPut10700Rdo.TabIndex = 34;
            this._janPut10700Rdo.TabStop = true;
            this._janPut10700Rdo.Text = "1月Put 10700";
            this._janPut10700Rdo.UseVisualStyleBackColor = true;
            this._janPut10700Rdo.CheckedChanged += new System.EventHandler(this._PutRdo_CheckedChanged);
            // 
            // _janPut10600Rdo
            // 
            this._janPut10600Rdo.ForeColor = System.Drawing.Color.Green;
            this._janPut10600Rdo.Location = new System.Drawing.Point(113, 207);
            this._janPut10600Rdo.Name = "_janPut10600Rdo";
            this._janPut10600Rdo.Size = new System.Drawing.Size(100, 25);
            this._janPut10600Rdo.TabIndex = 33;
            this._janPut10600Rdo.TabStop = true;
            this._janPut10600Rdo.Text = "1月Put 10600";
            this._janPut10600Rdo.UseVisualStyleBackColor = true;
            this._janPut10600Rdo.CheckedChanged += new System.EventHandler(this._PutRdo_CheckedChanged);
            // 
            // _janPut10500Rdo
            // 
            this._janPut10500Rdo.ForeColor = System.Drawing.Color.Green;
            this._janPut10500Rdo.Location = new System.Drawing.Point(7, 207);
            this._janPut10500Rdo.Name = "_janPut10500Rdo";
            this._janPut10500Rdo.Size = new System.Drawing.Size(100, 25);
            this._janPut10500Rdo.TabIndex = 32;
            this._janPut10500Rdo.TabStop = true;
            this._janPut10500Rdo.Text = "1月Put 10500";
            this._janPut10500Rdo.UseVisualStyleBackColor = true;
            this._janPut10500Rdo.CheckedChanged += new System.EventHandler(this._PutRdo_CheckedChanged);
            // 
            // _janCall11000Rdo
            // 
            this._janCall11000Rdo.ForeColor = System.Drawing.Color.Red;
            this._janCall11000Rdo.Location = new System.Drawing.Point(537, 176);
            this._janCall11000Rdo.Name = "_janCall11000Rdo";
            this._janCall11000Rdo.Size = new System.Drawing.Size(100, 25);
            this._janCall11000Rdo.TabIndex = 31;
            this._janCall11000Rdo.TabStop = true;
            this._janCall11000Rdo.Text = "1月Call 11000";
            this._janCall11000Rdo.UseVisualStyleBackColor = true;
            this._janCall11000Rdo.CheckedChanged += new System.EventHandler(this._CallRdo_CheckedChanged);
            // 
            // _janCall10900Rdo
            // 
            this._janCall10900Rdo.ForeColor = System.Drawing.Color.Red;
            this._janCall10900Rdo.Location = new System.Drawing.Point(431, 176);
            this._janCall10900Rdo.Name = "_janCall10900Rdo";
            this._janCall10900Rdo.Size = new System.Drawing.Size(100, 25);
            this._janCall10900Rdo.TabIndex = 30;
            this._janCall10900Rdo.TabStop = true;
            this._janCall10900Rdo.Text = "1月Call 10900";
            this._janCall10900Rdo.UseVisualStyleBackColor = true;
            this._janCall10900Rdo.CheckedChanged += new System.EventHandler(this._CallRdo_CheckedChanged);
            // 
            // _janCall10800Rdo
            // 
            this._janCall10800Rdo.ForeColor = System.Drawing.Color.Red;
            this._janCall10800Rdo.Location = new System.Drawing.Point(325, 176);
            this._janCall10800Rdo.Name = "_janCall10800Rdo";
            this._janCall10800Rdo.Size = new System.Drawing.Size(100, 25);
            this._janCall10800Rdo.TabIndex = 29;
            this._janCall10800Rdo.TabStop = true;
            this._janCall10800Rdo.Text = "1月Call 10800";
            this._janCall10800Rdo.UseVisualStyleBackColor = true;
            this._janCall10800Rdo.CheckedChanged += new System.EventHandler(this._CallRdo_CheckedChanged);
            // 
            // _janCall10700Rdo
            // 
            this._janCall10700Rdo.ForeColor = System.Drawing.Color.Red;
            this._janCall10700Rdo.Location = new System.Drawing.Point(219, 176);
            this._janCall10700Rdo.Name = "_janCall10700Rdo";
            this._janCall10700Rdo.Size = new System.Drawing.Size(100, 25);
            this._janCall10700Rdo.TabIndex = 28;
            this._janCall10700Rdo.TabStop = true;
            this._janCall10700Rdo.Text = "1月Call 10700";
            this._janCall10700Rdo.UseVisualStyleBackColor = true;
            this._janCall10700Rdo.CheckedChanged += new System.EventHandler(this._CallRdo_CheckedChanged);
            // 
            // _janCall10600Rdo
            // 
            this._janCall10600Rdo.ForeColor = System.Drawing.Color.Red;
            this._janCall10600Rdo.Location = new System.Drawing.Point(113, 176);
            this._janCall10600Rdo.Name = "_janCall10600Rdo";
            this._janCall10600Rdo.Size = new System.Drawing.Size(100, 25);
            this._janCall10600Rdo.TabIndex = 27;
            this._janCall10600Rdo.TabStop = true;
            this._janCall10600Rdo.Text = "1月Call 10600";
            this._janCall10600Rdo.UseVisualStyleBackColor = true;
            this._janCall10600Rdo.CheckedChanged += new System.EventHandler(this._CallRdo_CheckedChanged);
            // 
            // _janCall10500Rdo
            // 
            this._janCall10500Rdo.ForeColor = System.Drawing.Color.Red;
            this._janCall10500Rdo.Location = new System.Drawing.Point(7, 176);
            this._janCall10500Rdo.Name = "_janCall10500Rdo";
            this._janCall10500Rdo.Size = new System.Drawing.Size(100, 25);
            this._janCall10500Rdo.TabIndex = 26;
            this._janCall10500Rdo.TabStop = true;
            this._janCall10500Rdo.Text = "1月Call 10500";
            this._janCall10500Rdo.UseVisualStyleBackColor = true;
            this._janCall10500Rdo.CheckedChanged += new System.EventHandler(this._CallRdo_CheckedChanged);
            // 
            // _decPut11000Rdo
            // 
            this._decPut11000Rdo.ForeColor = System.Drawing.Color.Green;
            this._decPut11000Rdo.Location = new System.Drawing.Point(537, 145);
            this._decPut11000Rdo.Name = "_decPut11000Rdo";
            this._decPut11000Rdo.Size = new System.Drawing.Size(100, 25);
            this._decPut11000Rdo.TabIndex = 25;
            this._decPut11000Rdo.TabStop = true;
            this._decPut11000Rdo.Text = "12月Put 11000";
            this._decPut11000Rdo.UseVisualStyleBackColor = true;
            this._decPut11000Rdo.CheckedChanged += new System.EventHandler(this._PutRdo_CheckedChanged);
            // 
            // _decPut10900Rdo
            // 
            this._decPut10900Rdo.ForeColor = System.Drawing.Color.Green;
            this._decPut10900Rdo.Location = new System.Drawing.Point(431, 145);
            this._decPut10900Rdo.Name = "_decPut10900Rdo";
            this._decPut10900Rdo.Size = new System.Drawing.Size(100, 25);
            this._decPut10900Rdo.TabIndex = 24;
            this._decPut10900Rdo.TabStop = true;
            this._decPut10900Rdo.Text = "12月Put 10900";
            this._decPut10900Rdo.UseVisualStyleBackColor = true;
            this._decPut10900Rdo.CheckedChanged += new System.EventHandler(this._PutRdo_CheckedChanged);
            // 
            // _decPut10800Rdo
            // 
            this._decPut10800Rdo.ForeColor = System.Drawing.Color.Green;
            this._decPut10800Rdo.Location = new System.Drawing.Point(325, 145);
            this._decPut10800Rdo.Name = "_decPut10800Rdo";
            this._decPut10800Rdo.Size = new System.Drawing.Size(100, 25);
            this._decPut10800Rdo.TabIndex = 23;
            this._decPut10800Rdo.TabStop = true;
            this._decPut10800Rdo.Text = "12月Put 10800";
            this._decPut10800Rdo.UseVisualStyleBackColor = true;
            this._decPut10800Rdo.CheckedChanged += new System.EventHandler(this._PutRdo_CheckedChanged);
            // 
            // _decPut10700Rdo
            // 
            this._decPut10700Rdo.ForeColor = System.Drawing.Color.Green;
            this._decPut10700Rdo.Location = new System.Drawing.Point(219, 145);
            this._decPut10700Rdo.Name = "_decPut10700Rdo";
            this._decPut10700Rdo.Size = new System.Drawing.Size(100, 25);
            this._decPut10700Rdo.TabIndex = 22;
            this._decPut10700Rdo.TabStop = true;
            this._decPut10700Rdo.Text = "12月Put 10700";
            this._decPut10700Rdo.UseVisualStyleBackColor = true;
            this._decPut10700Rdo.CheckedChanged += new System.EventHandler(this._PutRdo_CheckedChanged);
            // 
            // _decPut10600Rdo
            // 
            this._decPut10600Rdo.ForeColor = System.Drawing.Color.Green;
            this._decPut10600Rdo.Location = new System.Drawing.Point(113, 145);
            this._decPut10600Rdo.Name = "_decPut10600Rdo";
            this._decPut10600Rdo.Size = new System.Drawing.Size(100, 25);
            this._decPut10600Rdo.TabIndex = 21;
            this._decPut10600Rdo.TabStop = true;
            this._decPut10600Rdo.Text = "12月Put 10600";
            this._decPut10600Rdo.UseVisualStyleBackColor = true;
            this._decPut10600Rdo.CheckedChanged += new System.EventHandler(this._PutRdo_CheckedChanged);
            // 
            // _decPut10500Rdo
            // 
            this._decPut10500Rdo.ForeColor = System.Drawing.Color.Green;
            this._decPut10500Rdo.Location = new System.Drawing.Point(7, 145);
            this._decPut10500Rdo.Name = "_decPut10500Rdo";
            this._decPut10500Rdo.Size = new System.Drawing.Size(100, 25);
            this._decPut10500Rdo.TabIndex = 20;
            this._decPut10500Rdo.TabStop = true;
            this._decPut10500Rdo.Text = "12月Put 10500";
            this._decPut10500Rdo.UseVisualStyleBackColor = true;
            this._decPut10500Rdo.CheckedChanged += new System.EventHandler(this._PutRdo_CheckedChanged);
            // 
            // _decCall11000Rdo
            // 
            this._decCall11000Rdo.ForeColor = System.Drawing.Color.Red;
            this._decCall11000Rdo.Location = new System.Drawing.Point(537, 114);
            this._decCall11000Rdo.Name = "_decCall11000Rdo";
            this._decCall11000Rdo.Size = new System.Drawing.Size(100, 25);
            this._decCall11000Rdo.TabIndex = 19;
            this._decCall11000Rdo.TabStop = true;
            this._decCall11000Rdo.Text = "12月Call 11000";
            this._decCall11000Rdo.UseVisualStyleBackColor = true;
            this._decCall11000Rdo.CheckedChanged += new System.EventHandler(this._CallRdo_CheckedChanged);
            // 
            // _decCall10900Rdo
            // 
            this._decCall10900Rdo.ForeColor = System.Drawing.Color.Red;
            this._decCall10900Rdo.Location = new System.Drawing.Point(431, 114);
            this._decCall10900Rdo.Name = "_decCall10900Rdo";
            this._decCall10900Rdo.Size = new System.Drawing.Size(100, 25);
            this._decCall10900Rdo.TabIndex = 18;
            this._decCall10900Rdo.TabStop = true;
            this._decCall10900Rdo.Text = "12月Call 10900";
            this._decCall10900Rdo.UseVisualStyleBackColor = true;
            this._decCall10900Rdo.CheckedChanged += new System.EventHandler(this._CallRdo_CheckedChanged);
            // 
            // _decCall10800Rdo
            // 
            this._decCall10800Rdo.ForeColor = System.Drawing.Color.Red;
            this._decCall10800Rdo.Location = new System.Drawing.Point(325, 114);
            this._decCall10800Rdo.Name = "_decCall10800Rdo";
            this._decCall10800Rdo.Size = new System.Drawing.Size(100, 25);
            this._decCall10800Rdo.TabIndex = 17;
            this._decCall10800Rdo.TabStop = true;
            this._decCall10800Rdo.Text = "12月Call 10800";
            this._decCall10800Rdo.UseVisualStyleBackColor = true;
            this._decCall10800Rdo.CheckedChanged += new System.EventHandler(this._CallRdo_CheckedChanged);
            // 
            // _decCall10700Rdo
            // 
            this._decCall10700Rdo.ForeColor = System.Drawing.Color.Red;
            this._decCall10700Rdo.Location = new System.Drawing.Point(219, 114);
            this._decCall10700Rdo.Name = "_decCall10700Rdo";
            this._decCall10700Rdo.Size = new System.Drawing.Size(100, 25);
            this._decCall10700Rdo.TabIndex = 16;
            this._decCall10700Rdo.TabStop = true;
            this._decCall10700Rdo.Text = "12月Call 10700";
            this._decCall10700Rdo.UseVisualStyleBackColor = true;
            this._decCall10700Rdo.CheckedChanged += new System.EventHandler(this._CallRdo_CheckedChanged);
            // 
            // _decCall10600Rdo
            // 
            this._decCall10600Rdo.ForeColor = System.Drawing.Color.Red;
            this._decCall10600Rdo.Location = new System.Drawing.Point(113, 114);
            this._decCall10600Rdo.Name = "_decCall10600Rdo";
            this._decCall10600Rdo.Size = new System.Drawing.Size(100, 25);
            this._decCall10600Rdo.TabIndex = 15;
            this._decCall10600Rdo.TabStop = true;
            this._decCall10600Rdo.Text = "12月Call 10600";
            this._decCall10600Rdo.UseVisualStyleBackColor = true;
            this._decCall10600Rdo.CheckedChanged += new System.EventHandler(this._CallRdo_CheckedChanged);
            // 
            // _decCall10500Rdo
            // 
            this._decCall10500Rdo.ForeColor = System.Drawing.Color.Red;
            this._decCall10500Rdo.Location = new System.Drawing.Point(7, 114);
            this._decCall10500Rdo.Name = "_decCall10500Rdo";
            this._decCall10500Rdo.Size = new System.Drawing.Size(100, 25);
            this._decCall10500Rdo.TabIndex = 14;
            this._decCall10500Rdo.TabStop = true;
            this._decCall10500Rdo.Text = "12月Call 10500";
            this._decCall10500Rdo.UseVisualStyleBackColor = true;
            this._decCall10500Rdo.CheckedChanged += new System.EventHandler(this._CallRdo_CheckedChanged);
            // 
            // _novPut11000Rdo
            // 
            this._novPut11000Rdo.ForeColor = System.Drawing.Color.Green;
            this._novPut11000Rdo.Location = new System.Drawing.Point(537, 83);
            this._novPut11000Rdo.Name = "_novPut11000Rdo";
            this._novPut11000Rdo.Size = new System.Drawing.Size(100, 25);
            this._novPut11000Rdo.TabIndex = 13;
            this._novPut11000Rdo.TabStop = true;
            this._novPut11000Rdo.Text = "11月Put 11000";
            this._novPut11000Rdo.UseVisualStyleBackColor = true;
            this._novPut11000Rdo.CheckedChanged += new System.EventHandler(this._PutRdo_CheckedChanged);
            // 
            // _novPut10900Rdo
            // 
            this._novPut10900Rdo.ForeColor = System.Drawing.Color.Green;
            this._novPut10900Rdo.Location = new System.Drawing.Point(431, 83);
            this._novPut10900Rdo.Name = "_novPut10900Rdo";
            this._novPut10900Rdo.Size = new System.Drawing.Size(100, 25);
            this._novPut10900Rdo.TabIndex = 12;
            this._novPut10900Rdo.TabStop = true;
            this._novPut10900Rdo.Text = "11月Put 10900";
            this._novPut10900Rdo.UseVisualStyleBackColor = true;
            this._novPut10900Rdo.CheckedChanged += new System.EventHandler(this._PutRdo_CheckedChanged);
            // 
            // _novPut10800Rdo
            // 
            this._novPut10800Rdo.ForeColor = System.Drawing.Color.Green;
            this._novPut10800Rdo.Location = new System.Drawing.Point(325, 83);
            this._novPut10800Rdo.Name = "_novPut10800Rdo";
            this._novPut10800Rdo.Size = new System.Drawing.Size(100, 25);
            this._novPut10800Rdo.TabIndex = 11;
            this._novPut10800Rdo.TabStop = true;
            this._novPut10800Rdo.Text = "11月Put 10800";
            this._novPut10800Rdo.UseVisualStyleBackColor = true;
            this._novPut10800Rdo.CheckedChanged += new System.EventHandler(this._PutRdo_CheckedChanged);
            // 
            // _novPut10700Rdo
            // 
            this._novPut10700Rdo.ForeColor = System.Drawing.Color.Green;
            this._novPut10700Rdo.Location = new System.Drawing.Point(219, 83);
            this._novPut10700Rdo.Name = "_novPut10700Rdo";
            this._novPut10700Rdo.Size = new System.Drawing.Size(100, 25);
            this._novPut10700Rdo.TabIndex = 10;
            this._novPut10700Rdo.TabStop = true;
            this._novPut10700Rdo.Text = "11月Put 10700";
            this._novPut10700Rdo.UseVisualStyleBackColor = true;
            this._novPut10700Rdo.CheckedChanged += new System.EventHandler(this._PutRdo_CheckedChanged);
            // 
            // _novPut10600Rdo
            // 
            this._novPut10600Rdo.ForeColor = System.Drawing.Color.Green;
            this._novPut10600Rdo.Location = new System.Drawing.Point(113, 83);
            this._novPut10600Rdo.Name = "_novPut10600Rdo";
            this._novPut10600Rdo.Size = new System.Drawing.Size(100, 25);
            this._novPut10600Rdo.TabIndex = 9;
            this._novPut10600Rdo.TabStop = true;
            this._novPut10600Rdo.Text = "11月Put 10600";
            this._novPut10600Rdo.UseVisualStyleBackColor = true;
            this._novPut10600Rdo.CheckedChanged += new System.EventHandler(this._PutRdo_CheckedChanged);
            // 
            // _novPut10500Rdo
            // 
            this._novPut10500Rdo.ForeColor = System.Drawing.Color.Green;
            this._novPut10500Rdo.Location = new System.Drawing.Point(7, 83);
            this._novPut10500Rdo.Name = "_novPut10500Rdo";
            this._novPut10500Rdo.Size = new System.Drawing.Size(100, 25);
            this._novPut10500Rdo.TabIndex = 8;
            this._novPut10500Rdo.TabStop = true;
            this._novPut10500Rdo.Text = "11月Put 10500";
            this._novPut10500Rdo.UseVisualStyleBackColor = true;
            this._novPut10500Rdo.CheckedChanged += new System.EventHandler(this._PutRdo_CheckedChanged);
            // 
            // _novCall11000Rdo
            // 
            this._novCall11000Rdo.ForeColor = System.Drawing.Color.Red;
            this._novCall11000Rdo.Location = new System.Drawing.Point(537, 52);
            this._novCall11000Rdo.Name = "_novCall11000Rdo";
            this._novCall11000Rdo.Size = new System.Drawing.Size(100, 25);
            this._novCall11000Rdo.TabIndex = 7;
            this._novCall11000Rdo.TabStop = true;
            this._novCall11000Rdo.Text = "11月Call 11000";
            this._novCall11000Rdo.UseVisualStyleBackColor = true;
            this._novCall11000Rdo.CheckedChanged += new System.EventHandler(this._CallRdo_CheckedChanged);
            // 
            // _novCall10900Rdo
            // 
            this._novCall10900Rdo.ForeColor = System.Drawing.Color.Red;
            this._novCall10900Rdo.Location = new System.Drawing.Point(431, 52);
            this._novCall10900Rdo.Name = "_novCall10900Rdo";
            this._novCall10900Rdo.Size = new System.Drawing.Size(100, 25);
            this._novCall10900Rdo.TabIndex = 6;
            this._novCall10900Rdo.TabStop = true;
            this._novCall10900Rdo.Text = "11月Call 10900";
            this._novCall10900Rdo.UseVisualStyleBackColor = true;
            this._novCall10900Rdo.CheckedChanged += new System.EventHandler(this._CallRdo_CheckedChanged);
            // 
            // _novCall10800Rdo
            // 
            this._novCall10800Rdo.ForeColor = System.Drawing.Color.Red;
            this._novCall10800Rdo.Location = new System.Drawing.Point(325, 52);
            this._novCall10800Rdo.Name = "_novCall10800Rdo";
            this._novCall10800Rdo.Size = new System.Drawing.Size(100, 25);
            this._novCall10800Rdo.TabIndex = 5;
            this._novCall10800Rdo.TabStop = true;
            this._novCall10800Rdo.Text = "11月Call 10800";
            this._novCall10800Rdo.UseVisualStyleBackColor = true;
            this._novCall10800Rdo.CheckedChanged += new System.EventHandler(this._CallRdo_CheckedChanged);
            // 
            // _novCall10700Rdo
            // 
            this._novCall10700Rdo.ForeColor = System.Drawing.Color.Red;
            this._novCall10700Rdo.Location = new System.Drawing.Point(219, 52);
            this._novCall10700Rdo.Name = "_novCall10700Rdo";
            this._novCall10700Rdo.Size = new System.Drawing.Size(100, 25);
            this._novCall10700Rdo.TabIndex = 4;
            this._novCall10700Rdo.TabStop = true;
            this._novCall10700Rdo.Text = "11月Call 10700";
            this._novCall10700Rdo.UseVisualStyleBackColor = true;
            this._novCall10700Rdo.CheckedChanged += new System.EventHandler(this._CallRdo_CheckedChanged);
            // 
            // _novCall10600Rdo
            // 
            this._novCall10600Rdo.ForeColor = System.Drawing.Color.Red;
            this._novCall10600Rdo.Location = new System.Drawing.Point(113, 52);
            this._novCall10600Rdo.Name = "_novCall10600Rdo";
            this._novCall10600Rdo.Size = new System.Drawing.Size(100, 25);
            this._novCall10600Rdo.TabIndex = 3;
            this._novCall10600Rdo.TabStop = true;
            this._novCall10600Rdo.Text = "11月Call 10600";
            this._novCall10600Rdo.UseVisualStyleBackColor = true;
            this._novCall10600Rdo.CheckedChanged += new System.EventHandler(this._CallRdo_CheckedChanged);
            // 
            // _novCall10500Rdo
            // 
            this._novCall10500Rdo.ForeColor = System.Drawing.Color.Red;
            this._novCall10500Rdo.Location = new System.Drawing.Point(7, 52);
            this._novCall10500Rdo.Name = "_novCall10500Rdo";
            this._novCall10500Rdo.Size = new System.Drawing.Size(100, 25);
            this._novCall10500Rdo.TabIndex = 2;
            this._novCall10500Rdo.TabStop = true;
            this._novCall10500Rdo.Text = "11月Call 10500";
            this._novCall10500Rdo.UseVisualStyleBackColor = true;
            this._novCall10500Rdo.CheckedChanged += new System.EventHandler(this._CallRdo_CheckedChanged);
            // 
            // _taifex12RdoBtn
            // 
            this._taifex12RdoBtn.Location = new System.Drawing.Point(113, 21);
            this._taifex12RdoBtn.Name = "_taifex12RdoBtn";
            this._taifex12RdoBtn.Size = new System.Drawing.Size(100, 25);
            this._taifex12RdoBtn.TabIndex = 1;
            this._taifex12RdoBtn.TabStop = true;
            this._taifex12RdoBtn.Text = "台指期12月";
            this._taifex12RdoBtn.UseVisualStyleBackColor = true;
            this._taifex12RdoBtn.CheckedChanged += new System.EventHandler(this._taifex12RdoBtn_CheckedChanged);
            // 
            // _taifex11RdoBtn
            // 
            this._taifex11RdoBtn.Location = new System.Drawing.Point(7, 21);
            this._taifex11RdoBtn.Name = "_taifex11RdoBtn";
            this._taifex11RdoBtn.Size = new System.Drawing.Size(100, 25);
            this._taifex11RdoBtn.TabIndex = 0;
            this._taifex11RdoBtn.TabStop = true;
            this._taifex11RdoBtn.Text = "台指期11月";
            this._taifex11RdoBtn.UseVisualStyleBackColor = true;
            this._taifex11RdoBtn.CheckedChanged += new System.EventHandler(this._taifex11RdoBtn_CheckedChanged);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(707, 404);
            this.Controls.Add(this._freqSymbolGbx);
            this.Controls.Add(this._qtyLbl);
            this.Controls.Add(this._priceLbl);
            this.Controls.Add(this._symbolLbl);
            this.Controls.Add(this._qtyTxt);
            this.Controls.Add(this._priceTxt);
            this.Controls.Add(this._sellRdoBtn);
            this.Controls.Add(this._buyRdoBtn);
            this.Controls.Add(this._symbolTxt);
            this.Controls.Add(this._openDirectoryBtn);
            this.Controls.Add(this._saveDirectorySettingBtn);
            this.Controls.Add(this._outputFileNameTxt);
            this.Controls.Add(this._outputDirectoryTxt);
            this.Controls.Add(this._batchFileNameLbl);
            this.Controls.Add(this._directoryLbl);
            this.Controls.Add(this._generateBtn);
            this.Name = "MainForm";
            this.Text = "Batch File Generator";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this._freqSymbolGbx.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button _generateBtn;
        private System.Windows.Forms.Label _directoryLbl;
        private System.Windows.Forms.Label _batchFileNameLbl;
        private System.Windows.Forms.TextBox _outputDirectoryTxt;
        private System.Windows.Forms.TextBox _outputFileNameTxt;
        private System.Windows.Forms.Button _saveDirectorySettingBtn;
        private System.Windows.Forms.Button _openDirectoryBtn;
        private System.Windows.Forms.FolderBrowserDialog _directoryDlg;
        private System.Windows.Forms.TextBox _symbolTxt;
        private System.Windows.Forms.RadioButton _buyRdoBtn;
        private System.Windows.Forms.RadioButton _sellRdoBtn;
        private System.Windows.Forms.TextBox _priceTxt;
        private System.Windows.Forms.TextBox _qtyTxt;
        private System.Windows.Forms.Label _symbolLbl;
        private System.Windows.Forms.Label _priceLbl;
        private System.Windows.Forms.Label _qtyLbl;
        private System.Windows.Forms.GroupBox _freqSymbolGbx;
        private System.Windows.Forms.RadioButton _taifex12RdoBtn;
        private System.Windows.Forms.RadioButton _taifex11RdoBtn;
        private System.Windows.Forms.RadioButton _janPut11000Rdo;
        private System.Windows.Forms.RadioButton _janPut10900Rdo;
        private System.Windows.Forms.RadioButton _janPut10800Rdo;
        private System.Windows.Forms.RadioButton _janPut10700Rdo;
        private System.Windows.Forms.RadioButton _janPut10600Rdo;
        private System.Windows.Forms.RadioButton _janPut10500Rdo;
        private System.Windows.Forms.RadioButton _janCall11000Rdo;
        private System.Windows.Forms.RadioButton _janCall10900Rdo;
        private System.Windows.Forms.RadioButton _janCall10800Rdo;
        private System.Windows.Forms.RadioButton _janCall10700Rdo;
        private System.Windows.Forms.RadioButton _janCall10600Rdo;
        private System.Windows.Forms.RadioButton _janCall10500Rdo;
        private System.Windows.Forms.RadioButton _decPut11000Rdo;
        private System.Windows.Forms.RadioButton _decPut10900Rdo;
        private System.Windows.Forms.RadioButton _decPut10800Rdo;
        private System.Windows.Forms.RadioButton _decPut10700Rdo;
        private System.Windows.Forms.RadioButton _decPut10600Rdo;
        private System.Windows.Forms.RadioButton _decPut10500Rdo;
        private System.Windows.Forms.RadioButton _decCall11000Rdo;
        private System.Windows.Forms.RadioButton _decCall10900Rdo;
        private System.Windows.Forms.RadioButton _decCall10800Rdo;
        private System.Windows.Forms.RadioButton _decCall10700Rdo;
        private System.Windows.Forms.RadioButton _decCall10600Rdo;
        private System.Windows.Forms.RadioButton _decCall10500Rdo;
        private System.Windows.Forms.RadioButton _novPut11000Rdo;
        private System.Windows.Forms.RadioButton _novPut10900Rdo;
        private System.Windows.Forms.RadioButton _novPut10800Rdo;
        private System.Windows.Forms.RadioButton _novPut10700Rdo;
        private System.Windows.Forms.RadioButton _novPut10600Rdo;
        private System.Windows.Forms.RadioButton _novPut10500Rdo;
        private System.Windows.Forms.RadioButton _novCall11000Rdo;
        private System.Windows.Forms.RadioButton _novCall10900Rdo;
        private System.Windows.Forms.RadioButton _novCall10800Rdo;
        private System.Windows.Forms.RadioButton _novCall10700Rdo;
        private System.Windows.Forms.RadioButton _novCall10600Rdo;
        private System.Windows.Forms.RadioButton _novCall10500Rdo;
    }
}

