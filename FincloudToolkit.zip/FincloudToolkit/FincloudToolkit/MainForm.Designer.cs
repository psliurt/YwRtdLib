﻿namespace FincloudToolkit
{
    partial class MainForm
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this._generateBtn = new System.Windows.Forms.Button();
            this._directoryLbl = new System.Windows.Forms.Label();
            this._batchFileNameLbl = new System.Windows.Forms.Label();
            this._outputDirectoryTxt = new System.Windows.Forms.TextBox();
            this._outputFileNameTxt = new System.Windows.Forms.TextBox();
            this._saveDirectorySettingBtn = new System.Windows.Forms.Button();
            this._openDirectoryBtn = new System.Windows.Forms.Button();
            this._directoryDlg = new System.Windows.Forms.FolderBrowserDialog();
            this._symbolTxt = new System.Windows.Forms.TextBox();
            this._buyRdoBtn = new System.Windows.Forms.RadioButton();
            this._sellRdoBtn = new System.Windows.Forms.RadioButton();
            this._priceTxt = new System.Windows.Forms.TextBox();
            this._qtyTxt = new System.Windows.Forms.TextBox();
            this._symbolLbl = new System.Windows.Forms.Label();
            this._priceLbl = new System.Windows.Forms.Label();
            this._qtyLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // _generateBtn
            // 
            this._generateBtn.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._generateBtn.Location = new System.Drawing.Point(489, 108);
            this._generateBtn.Name = "_generateBtn";
            this._generateBtn.Size = new System.Drawing.Size(206, 34);
            this._generateBtn.TabIndex = 0;
            this._generateBtn.Text = "產生批次檔";
            this._generateBtn.UseVisualStyleBackColor = true;
            this._generateBtn.Click += new System.EventHandler(this._generateBtn_Click);
            // 
            // _directoryLbl
            // 
            this._directoryLbl.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._directoryLbl.Location = new System.Drawing.Point(12, 13);
            this._directoryLbl.Name = "_directoryLbl";
            this._directoryLbl.Size = new System.Drawing.Size(100, 23);
            this._directoryLbl.TabIndex = 1;
            this._directoryLbl.Text = "資料夾";
            this._directoryLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // _batchFileNameLbl
            // 
            this._batchFileNameLbl.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._batchFileNameLbl.Location = new System.Drawing.Point(12, 53);
            this._batchFileNameLbl.Name = "_batchFileNameLbl";
            this._batchFileNameLbl.Size = new System.Drawing.Size(100, 23);
            this._batchFileNameLbl.TabIndex = 2;
            this._batchFileNameLbl.Text = "檔案名稱";
            this._batchFileNameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // _outputDirectoryTxt
            // 
            this._outputDirectoryTxt.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._outputDirectoryTxt.Location = new System.Drawing.Point(118, 9);
            this._outputDirectoryTxt.Name = "_outputDirectoryTxt";
            this._outputDirectoryTxt.Size = new System.Drawing.Size(465, 27);
            this._outputDirectoryTxt.TabIndex = 3;
            // 
            // _outputFileNameTxt
            // 
            this._outputFileNameTxt.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._outputFileNameTxt.Location = new System.Drawing.Point(118, 53);
            this._outputFileNameTxt.Name = "_outputFileNameTxt";
            this._outputFileNameTxt.Size = new System.Drawing.Size(423, 27);
            this._outputFileNameTxt.TabIndex = 4;
            // 
            // _saveDirectorySettingBtn
            // 
            this._saveDirectorySettingBtn.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._saveDirectorySettingBtn.Location = new System.Drawing.Point(547, 47);
            this._saveDirectorySettingBtn.Name = "_saveDirectorySettingBtn";
            this._saveDirectorySettingBtn.Size = new System.Drawing.Size(148, 34);
            this._saveDirectorySettingBtn.TabIndex = 5;
            this._saveDirectorySettingBtn.Text = "保存資料夾設定";
            this._saveDirectorySettingBtn.UseVisualStyleBackColor = true;
            this._saveDirectorySettingBtn.Click += new System.EventHandler(this._saveDirectorySettingBtn_Click);
            // 
            // _openDirectoryBtn
            // 
            this._openDirectoryBtn.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._openDirectoryBtn.Location = new System.Drawing.Point(589, 7);
            this._openDirectoryBtn.Name = "_openDirectoryBtn";
            this._openDirectoryBtn.Size = new System.Drawing.Size(106, 34);
            this._openDirectoryBtn.TabIndex = 6;
            this._openDirectoryBtn.Text = "選取資料夾";
            this._openDirectoryBtn.UseVisualStyleBackColor = true;
            this._openDirectoryBtn.Click += new System.EventHandler(this._openDirectoryBtn_Click);
            // 
            // _symbolTxt
            // 
            this._symbolTxt.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._symbolTxt.Location = new System.Drawing.Point(12, 114);
            this._symbolTxt.Name = "_symbolTxt";
            this._symbolTxt.Size = new System.Drawing.Size(137, 27);
            this._symbolTxt.TabIndex = 7;
            // 
            // _buyRdoBtn
            // 
            this._buyRdoBtn.Location = new System.Drawing.Point(155, 112);
            this._buyRdoBtn.Name = "_buyRdoBtn";
            this._buyRdoBtn.Size = new System.Drawing.Size(55, 27);
            this._buyRdoBtn.TabIndex = 8;
            this._buyRdoBtn.TabStop = true;
            this._buyRdoBtn.Text = "Buy";
            this._buyRdoBtn.UseVisualStyleBackColor = true;
            // 
            // _sellRdoBtn
            // 
            this._sellRdoBtn.Location = new System.Drawing.Point(216, 112);
            this._sellRdoBtn.Name = "_sellRdoBtn";
            this._sellRdoBtn.Size = new System.Drawing.Size(55, 27);
            this._sellRdoBtn.TabIndex = 9;
            this._sellRdoBtn.TabStop = true;
            this._sellRdoBtn.Text = "Sell";
            this._sellRdoBtn.UseVisualStyleBackColor = true;
            // 
            // _priceTxt
            // 
            this._priceTxt.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._priceTxt.Location = new System.Drawing.Point(277, 113);
            this._priceTxt.Name = "_priceTxt";
            this._priceTxt.Size = new System.Drawing.Size(100, 27);
            this._priceTxt.TabIndex = 10;
            // 
            // _qtyTxt
            // 
            this._qtyTxt.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._qtyTxt.Location = new System.Drawing.Point(383, 112);
            this._qtyTxt.Name = "_qtyTxt";
            this._qtyTxt.Size = new System.Drawing.Size(97, 27);
            this._qtyTxt.TabIndex = 11;
            // 
            // _symbolLbl
            // 
            this._symbolLbl.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._symbolLbl.Location = new System.Drawing.Point(12, 88);
            this._symbolLbl.Name = "_symbolLbl";
            this._symbolLbl.Size = new System.Drawing.Size(162, 23);
            this._symbolLbl.TabIndex = 12;
            this._symbolLbl.Text = "商品";
            this._symbolLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _priceLbl
            // 
            this._priceLbl.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._priceLbl.Location = new System.Drawing.Point(277, 88);
            this._priceLbl.Name = "_priceLbl";
            this._priceLbl.Size = new System.Drawing.Size(100, 23);
            this._priceLbl.TabIndex = 13;
            this._priceLbl.Text = "價格";
            this._priceLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _qtyLbl
            // 
            this._qtyLbl.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this._qtyLbl.Location = new System.Drawing.Point(383, 88);
            this._qtyLbl.Name = "_qtyLbl";
            this._qtyLbl.Size = new System.Drawing.Size(100, 23);
            this._qtyLbl.TabIndex = 14;
            this._qtyLbl.Text = "數量";
            this._qtyLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(707, 155);
            this.Controls.Add(this._qtyLbl);
            this.Controls.Add(this._priceLbl);
            this.Controls.Add(this._symbolLbl);
            this.Controls.Add(this._qtyTxt);
            this.Controls.Add(this._priceTxt);
            this.Controls.Add(this._sellRdoBtn);
            this.Controls.Add(this._buyRdoBtn);
            this.Controls.Add(this._symbolTxt);
            this.Controls.Add(this._openDirectoryBtn);
            this.Controls.Add(this._saveDirectorySettingBtn);
            this.Controls.Add(this._outputFileNameTxt);
            this.Controls.Add(this._outputDirectoryTxt);
            this.Controls.Add(this._batchFileNameLbl);
            this.Controls.Add(this._directoryLbl);
            this.Controls.Add(this._generateBtn);
            this.Name = "MainForm";
            this.Text = "Batch File Generator";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button _generateBtn;
        private System.Windows.Forms.Label _directoryLbl;
        private System.Windows.Forms.Label _batchFileNameLbl;
        private System.Windows.Forms.TextBox _outputDirectoryTxt;
        private System.Windows.Forms.TextBox _outputFileNameTxt;
        private System.Windows.Forms.Button _saveDirectorySettingBtn;
        private System.Windows.Forms.Button _openDirectoryBtn;
        private System.Windows.Forms.FolderBrowserDialog _directoryDlg;
        private System.Windows.Forms.TextBox _symbolTxt;
        private System.Windows.Forms.RadioButton _buyRdoBtn;
        private System.Windows.Forms.RadioButton _sellRdoBtn;
        private System.Windows.Forms.TextBox _priceTxt;
        private System.Windows.Forms.TextBox _qtyTxt;
        private System.Windows.Forms.Label _symbolLbl;
        private System.Windows.Forms.Label _priceLbl;
        private System.Windows.Forms.Label _qtyLbl;
    }
}

